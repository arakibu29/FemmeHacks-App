import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
      Chestnut Hill College
      </Text>
      <Image style={styles.logo} source={require('../assets/chcollege.png')} />
        <Text style={styles.centerQ}>
          <Text style={styles.info}> Status:</Text> <Text> Undergraduate- Virtual</Text> 
        </Text>

        <Text style={styles.centerQ}>
          <Text style={styles.info}> Sector: </Text> <Text>Dark Blue</Text>
        </Text>

        <Text style={styles.centerQ}>
          <Text style={styles.info}> Location: </Text> <Text>Germantown Ave, Chestnut Hill </Text>
        </Text>

        <Text style={styles.centerQ}>
          <Text style={styles.info}> Positive Cases: </Text> <Text>326 since 10/12/2020</Text>
        </Text>

        <Text style={styles.centerQ}>
          <Text style={styles.info}> Enrollment: </Text> <Text>2,500</Text>
        </Text>

        <Text style={styles.centerQ}>
          <Text style={styles.info}> Percent Positivity: </Text> <Text>0.88% (weekly average)</Text>
        </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  info: {
    fontSize: 20,
    fontWeight: 'bold',
    textDecorationLine: 'underline',
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  logo: {
    height: 128,
    width: 128,
  },
  graph: {
    height: 150,
    width: 200,
  },
});