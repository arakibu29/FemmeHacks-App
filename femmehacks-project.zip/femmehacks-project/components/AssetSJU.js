import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Saint Joseph's University
      </Text>
      <Image style={styles.logo} source={require('../assets/sju.png')} />

        <Text>
          <Text style={styles.info}> Status:</Text> Hybrid
        </Text>

        <Text>
          <Text style={styles.info}> Sector:</Text> Light Blue
        </Text>

        <Text>
          <Text style={styles.info}> Location:</Text> <Text> City Ave, Lower Merion/Philadelphia </Text> 
        </Text>

        <Text>
          <Text style={styles.info}> Positive Cases:</Text> 480
        </Text>

        <Text>
          <Text style={styles.info}> Enrollment:</Text> 8,500
        </Text>

        <Text>
          <Text style={styles.info}> Percent Positivity:</Text> 4.6%
        </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
  },
    info: {
    fontSize: 20,
    fontWeight: 'bold',
    textDecorationLine: 'underline',
  },
  logo: {
    height: 128,
    width: 128,
  },
  graph: {
    height: 150,
    width: 200,
  },
});