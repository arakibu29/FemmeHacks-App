import React from 'react';
import { Text, StyleSheet, TouchableOpacity } from 'react-native'

const Shopping = (props) => {
  return (
      <TouchableOpacity
        onPress={props.onPress}
        style={styles.shoppingBody}>
      <Text style={styles.buttonzText}>
      { props.children }
        </Text>
      </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  shoppingBody: {
    backgroundColor: '#e0ffff',
    width: '50%', 
    padding: 20,
    alignItems: 'center',
    flex:1,
    justifyContent: 'center',
    borderRasius: 8,
    marginBottom: 10,
    flexDirection: 'row',
    marginLeft: 90,
  },
  buttonzText: {
    color: '#f0f8ff',
    fontSize: 18,
    fontWeight: '600',
  }
})
export { Shopping } ;