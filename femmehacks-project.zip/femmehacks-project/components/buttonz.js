import React from 'react';
import { Text, StyleSheet, TouchableOpacity } from 'react-native'

const Buttonz = (props) => {
  return (
      <TouchableOpacity
        onPress={props.onPress}
        style={styles.buttonzBody}>
      <Text style={styles.buttonzText}>
      { props.children }
        </Text>
      </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  buttonzBody: {
    backgroundColor: '#696969',
    width: '100%', 
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderRasius: 8,
    marginBottom: 60,
  },
  buttonzText: {
    color: '#f0f8ff',
    fontSize: 18,
    fontWeight: '600',
  }
})
export { Buttonz } ;
