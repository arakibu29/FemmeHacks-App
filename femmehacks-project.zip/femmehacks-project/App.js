import React, { useState, useEffect, Component } from "react";
import { Text, StyleSheet, View, Button, TextInput, ScrollView, Alert, TouchableWithoutFeedback, Keyboard, SafeAreaView, TouchableOpacity, AsyncStorage, Dimensions, Linking, Image } from "react-native";
import Constants from 'expo-constants';

import { Buttonz } from './components/buttonz';

import { Shopping } from './components/shopping';

import { UnivButton } from './components/univButton';

// You can import from local files
import AssetExample from './components/AssetExample';

import AssetUPenn from './components/AssetUPenn';

import AssetPhillyMap from './components/AssetPhillyMap';

import AssetCHCollege from './components/AssetCHCollege';

import AssetDrexel from './components/AssetDrexel';

import AssetSJU from './components/AssetSJU';

import AssetTemple from './components/AssetTemple';

import AssetColorMap from './components/AssetColorMap';

import AssetTesting from './components/AssetTesting';

import AssetReport from './components/AssetReport';

import AssetCollegeNearYou from './components/AssetCollegeNearYou';
// or any pure javascript modules available in npm
//import { Card } from 'react-native-paper';

import { Card } from 'react-native-paper';

import { WebView } from 'react-native-webview';


export default function App() {
  return (
<View>
<ScrollView>



      <Text style={styles.title}> 
        Univerona
      </Text>

    <Text style={styles.paragraph}>
        Welcome to Univerona! Your one stop shop for all things Covid while living on campus in Philly. From buying Personal Protective Equipment for class to reporting non-socially distant ragers, we've got it all here. Enjoy and stay safe!
    </Text>
    




<Text style={styles.header}> Location</Text>

      <View style={styles.container}>
        <Card>
          <AssetColorMap />
            <Text style={styles.sector1}> Red= North Philly</Text>
            <Text style={styles.sector2}> Dark Blue= Chestnut Hill</Text>
            <Text style={styles.sector3}> Light Blue= Ardmore and Upper Merion</Text>
            <Text style={styles.sector4}> Black= University City</Text>
            <Text style={styles.sector5}> Green= Center City and South Philly</Text>

              <Shopping>
                    <Text style={styles.TextStyle} onPress={ ()=> Linking.openURL('https://www.google.com/maps') }> Check where you are with Google Maps </Text>
              </Shopping>

        </Card>
      </View>




          <TextInput 
            style={styles.input}
            placeholder='e.g. Green'
          />
      <View>

      <View style={styles.container}>
        <Card>
          <AssetCollegeNearYou />
            <Text style={styles.sector1}> Red</Text>
              <Text style={styles.smallerText}> Temple is near you</Text>
            <Text style={styles.sector2}> Dark Blue</Text>
              <Text style={styles.smallerText}> Chestnut Hill College is near you</Text>
            <Text style={styles.sector3}> Light Blue</Text>
              <Text style={styles.smallerText}> Saint Joe's is near you </Text>
            <Text style={styles.sector4}> Black</Text>
              <Text style={styles.smallerText}> Drexel and UPenn are near you</Text>
            <Text style={styles.sector5}> Green</Text>
              <Text style={styles.smallerText}> No colleges near you</Text>

              <Shopping>
                    <Text style={styles.TextStyle} onPress={ ()=> Linking.openURL('https://www.google.com/maps') }> Check where you are with Google Maps </Text>
              </Shopping>

        </Card>
      </View>
            
<Text style={styles.header}> College Rona Rates</Text>


       <View style={styles.container}> 
        <Card>
          <AssetUPenn />
                  <Shopping>
                    <Text style={styles.TextStyle} onPress={ ()=> Linking.openURL('https://coronavirus.upenn.edu/') }> UPenn's Covid Page </Text>
                    </Shopping>
        </Card>
      </View>


      <View style={styles.container}>
        <Card>
          <AssetCHCollege />
                  <Shopping>
                    <Text style={styles.TextStyle} onPress={ ()=> Linking.openURL('https://www.chc.edu/chestnut-hill-college-covid-19-dashboard') }> CHC's Covid Page </Text>
                    </Shopping>
        </Card>
      </View>


      <View style={styles.container}>
        <Card>
          <AssetDrexel />
                <Shopping>
                    <Text style={styles.TextStyle} onPress={ ()=> Linking.openURL('https://drexel.edu/hr/about/covid-19-resources/') }> Drexel's Covid Page </Text>
                </Shopping>
        </Card>
      </View>


      <View style={styles.container}>
        <Card>
          <AssetSJU />
                  <Shopping>
                    <Text style={styles.TextStyle} onPress={ ()=> Linking.openURL('https://www.sju.edu/hawk-hill-ahead/announcements/covid-19-dashboard') }> SJU's Covid Page </Text>
                    </Shopping>
        </Card>
      </View>

       <View style={styles.container}>
        <Card>
          <AssetTemple />
                  <Shopping>
                    <Text style={styles.TextStyle} onPress={ ()=> Linking.openURL('https://www.temple.edu/coronavirus/campus-communication/covid-19-dashboard') }> Temple's Website </Text>
                    </Shopping>
        </Card>
      </View>




        </View>

    <View>

<Text style={styles.header}> 
        Philadelphia Testing Centers
    </Text>

       <View style={styles.container}>
        <Card>
          <AssetTesting />
                  <Shopping>
                    <Text style={styles.TextStyle} onPress={ ()=> Linking.openURL('https://www.google.com/maps/d/u/0/edit?mid=13Q3_42NxNA3ZZmQMxoDMSuCXoCoY58dj&ll=39.99193720070315%2C-75.18781438730467&z=12') }> All Philly Testing Sites </Text>
                    </Shopping>

        </Card>
      </View>

    </View>



<View>
 <Text style={styles.header}> Report a Rager!</Text>
  <View style={styles.container}>
        <Card>
          <AssetReport />
                  <Shopping>
                    <Text style={styles.TextStyle} onPress={ ()=> Linking.openURL('https://www.publicsafety.upenn.edu/safety-initiatives/safetytips/') }> Philadelphia Security Contacts </Text>
                    </Shopping>

        </Card>
      </View>
</View> 




<View>
  <Text style={styles.header}> PPE Resources!</Text>

        <Text style={styles.smallerText}>
          Below are links for masks, hand sanitizers, door openers, faceshields, gloves, face shields.
        </Text>

  <Shopping>
                    <Text style={styles.TextStyle} onPress={ ()=> Linking.openURL('https://thepowerofblue.org/') }> Masks on Amazon </Text>
            </Shopping>

            <Shopping>
                    <Text style={styles.TextStyle} onPress={ ()=> Linking.openURL('https://www.walmart.com/ip/Equate-Moisturizing-Hand-Sanitizer-with-Vitamin-E-34-fl-oz/439877061?irgwc=1&sourceid=imp_0wU13s3uWxyLTfbwUx0Mo372UkEWm8RdR13RRw0&veh=aff&wmlspartner=imp_10078&clickid=0wU13s3uWxyLTfbwUx0Mo372UkEWm8RdR13RRw0&sharedid=prevention.com&affiliates_ad_id=612734&campaign_id=9383') }> Hand Sani </Text>
            </Shopping>

            <Shopping>
                    <Text style={styles.TextStyle} onPress={ ()=> Linking.openURL('https://www.amazon.com/Touchless-Sanitary-Germaphobe-Keychain-Multiple/dp/B089SQFNXN') }> No-touch door opener </Text>
            </Shopping>

            <Shopping>
                    <Text style={styles.TextStyle} onPress={ ()=> Linking.openURL('https://www.amazon.com/All-Round-Covering-Lightweight-Transparent-Adjustable/dp/B08GY3S85M/ref=sr_1_3_sspa?dchild=1&keywords=face+shield&qid=1612623502&sr=8-3-spons&psc=1&smid=A3UX71VCM39EX7&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUExRkc1UFM1MTdUT1pPJmVuY3J5cHRlZElkPUEwMzAxMjI3M0cxVTdJM0FTT045RSZlbmNyeXB0ZWRBZElkPUEwMTcxMTM1M0ZSTjMxRFBJMUtGNSZ3aWRnZXROYW1lPXNwX2F0ZiZhY3Rpb249Y2xpY2tSZWRpcmVjdCZkb05vdExvZ0NsaWNrPXRydWU=') }> Faceshields on Amazon </Text>
            </Shopping>

            <Shopping>
                    <Text style={styles.TextStyle} onPress={ ()=> Linking.openURL('https://www.amazon.com/dp/B0868XSLWZ?tag=rollingston07-20&linkCode=ogi&th=1&psc=1&language=en_US') }> Gloves </Text>
            </Shopping>




</View>


    <View style={styles.container}>
      <Card style={{padding: 10, margin: 10}}>
        <Text>Thanks for using Univerona!</Text>
        <Text>Wear you mask and stay safe!</Text>
      </Card>
      <Card style={{padding: 10, margin: 10}}>
        <Button
          onPress={()=>{}}
          title="got ur neck"
          color="#9acd32"
          accessibilityLabel="Learn more about this purple button"
        />
      </Card>
    </View>


</ScrollView>
    </View>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },

  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
    header: {
    backgroundColor: '#afeeee',
    padding: 20,
    fontWeight: 'bold',
    fontSize: 14
  },
    sector1: {
      marginLeft: 20,
      fontSize: 17,
      fontWeight: 'bold',
      color: 'red',
    },
      sector2: {
      marginLeft: 20,
      fontSize: 17,
      fontWeight: 'bold',
      color: 'darkblue'
    },
    sector3: {
      marginLeft: 20,
      fontSize: 17,
      fontWeight: 'bold',
      color: 'lightblue',
    },
    sector4: {
      marginLeft: 20,
      fontSize: 17,
      fontWeight: 'bold',
      color: 'black',
    },
    sector5: {
      marginLeft: 20,
      fontSize: 17,
      fontWeight: 'bold',
      color: 'green',
    },
    smallerText: {
    //backgroundColor: '#afeeee',
    padding: 20,
    //fontWeight: 'bold',
    fontSize: 12
  },
    neighborhoods: {
      fontSize: 20,
      textAlignVertical: 'center',
      textDecorationLine: 'underline',
      fontAlign: 'left',
    },

    title: {
    color: '#7b68ee',
    //flex: 1,
    backgroundColor: '#e0ffff',
    paddingTop: 20,
    fontSize: 48,
    fontWeight: 'bold',
    textAlignVertical: "center",
    textAlign: "center",
    textDecorationLine: 'underline',
  },

    input: {
    borderWidth: 1,
    borderColor:'#7b68ee',
    padding: 8,
    margin: 10,
    width: 350,
    fontSize: 40
  },

    MainContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
 
  TextStyle: {
 
    color: '#000000',
    textDecorationLine: 'underline'
 
  },


});